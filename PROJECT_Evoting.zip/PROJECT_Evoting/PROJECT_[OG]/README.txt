--software
mysql db
python

--install for project
pip install django
pip install mysqlclient
pip install mysql-connector-python
pip install cryptography
pip install opencv-python

--run using
python manage.py runserver

--migrate database
python manage.py makemigrations
python manage.py migrate

--html files in
templates/

--servlet/views
views.py

--urls
urls.py

--use on browser
https://localhost:8000/